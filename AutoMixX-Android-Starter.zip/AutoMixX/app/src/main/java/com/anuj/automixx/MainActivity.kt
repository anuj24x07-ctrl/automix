package com.anuj.automixx

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : AppCompatActivity() {
    private val pickFolder = 41
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var trackList: LinearLayout
    private lateinit var playButton: Button
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var activeSlot = 0
    private lateinit var players: Array<ExoPlayer>
    private var transitionRunning = false
    private var pollRunnable: Runnable? = null
    private val crossfadeMs = 8000L

    data class Track(val name: String, val uri: Uri)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        players = arrayOf(ExoPlayer.Builder(this).build(), ExoPlayer.Builder(this).build())
        buildUi()
        status.text = "Choose a folder containing your FLAC / MP3 music."
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101018.toInt())
        }
        val title = TextView(this).apply {
            text = "AutoMix X"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Local Music • Smart Mix Foundation"
            textSize = 13f
            setTextColor(0xFFB8B8C8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 20)
        }
        val choose = Button(this).apply {
            text = "Choose Music Folder"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                startActivityForResult(intent, pickFolder)
            }
        }
        playButton = Button(this).apply {
            text = "Play / Pause"
            isEnabled = false
            setOnClickListener { togglePlayback() }
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFE7E7F0.toInt())
            setPadding(0, 16, 0, 16)
            text = "No music folder selected."
        }
        trackList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(trackList) }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(choose)
        outer.addView(playButton)
        outer.addView(status)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    @Deprecated("Deprecated in Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFolder || resultCode != Activity.RESULT_OK) return
        val treeUri = data?.data ?: return
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        contentResolver.takePersistableUriPermission(treeUri, flags)
        tracks.clear()
        val folder = DocumentFile.fromTreeUri(this, treeUri)
        collectAudio(folder)
        tracks.sortBy { it.name.lowercase() }
        renderTracks()
        status.text = if (tracks.isEmpty()) "No supported audio files found." else "${tracks.size} tracks loaded. Tap a song to play."
        playButton.isEnabled = tracks.isNotEmpty()
    }

    private fun collectAudio(folder: DocumentFile?) {
        folder?.listFiles()?.forEach { file ->
            if (file.isDirectory) collectAudio(file)
            else {
                val name = file.name ?: return@forEach
                val lower = name.lowercase()
                if (lower.endsWith(".flac") || lower.endsWith(".mp3") ||
                    lower.endsWith(".m4a") || lower.endsWith(".wav") ||
                    lower.endsWith(".ogg") || lower.endsWith(".aac")) {
                    tracks.add(Track(name, file.uri))
                }
            }
        }
    }

    private fun renderTracks() {
        trackList.removeAllViews()
        tracks.forEachIndexed { index, track ->
            val row = TextView(this).apply {
                text = "${index + 1}. ${track.name}"
                textSize = 14f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(12, 14, 12, 14)
                setOnClickListener { playTrack(index) }
            }
            trackList.addView(row)
            val divider = View(this).apply { setBackgroundColor(0xFF30303D.toInt()) }
            trackList.addView(divider, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun playTrack(index: Int) {
        if (tracks.isEmpty()) return
        stopPolling()
        transitionRunning = false
        players.forEach { it.stop(); it.clearMediaItems(); it.volume = 0f }
        currentIndex = index
        activeSlot = 0
        val player = players[activeSlot]
        player.volume = 1f
        player.setMediaItem(MediaItem.fromUri(tracks[currentIndex].uri))
        player.prepare()
        player.play()
        status.text = "Playing: ${tracks[currentIndex].name}"
        startPolling()
    }

    private fun togglePlayback() {
        val player = players[activeSlot]
        if (player.isPlaying) {
            player.pause()
            players[1 - activeSlot].pause()
            status.text = "Paused"
        } else {
            player.play()
            if (transitionRunning) players[1 - activeSlot].play()
            status.text = "Playing: ${tracks.getOrNull(currentIndex)?.name ?: ""}"
            startPolling()
        }
    }

    private fun startPolling() {
        stopPolling()
        pollRunnable = object : Runnable {
            override fun run() {
                val current = players[activeSlot]
                if (current.isPlaying && !transitionRunning && current.duration > 0) {
                    val remaining = current.duration - current.currentPosition
                    if (remaining <= crossfadeMs && currentIndex < tracks.lastIndex) {
                        beginCrossfade()
                    }
                }
                handler.postDelayed(this, 400)
            }
        }
        handler.post(pollRunnable!!)
    }

    private fun beginCrossfade() {
        if (transitionRunning || currentIndex >= tracks.lastIndex) return
        transitionRunning = true
        val oldSlot = activeSlot
        val newSlot = 1 - activeSlot
        val incoming = players[newSlot]
        incoming.stop()
        incoming.clearMediaItems()
        incoming.setMediaItem(MediaItem.fromUri(tracks[currentIndex + 1].uri))
        incoming.volume = 0f
        incoming.prepare()
        incoming.playWhenReady = true

        incoming.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && transitionRunning) {
                    incoming.removeListener(this)
                    val animator = ValueAnimator.ofFloat(0f, 1f).apply {
                        duration = crossfadeMs
                        addUpdateListener {
                            val fraction = it.animatedValue as Float
                            players[oldSlot].volume = 1f - fraction
                            players[newSlot].volume = fraction
                        }
                        addListener(object : android.animation.AnimatorListenerAdapter() {
                            override fun onAnimationEnd(animation: android.animation.Animator) {
                                players[oldSlot].pause()
                                players[oldSlot].volume = 0f
                                players[newSlot].volume = 1f
                                activeSlot = newSlot
                                currentIndex++
                                transitionRunning = false
                                status.text = "Playing: ${tracks[currentIndex].name}"
                            }
                        })
                    }
                    animator.start()
                }
            }
        })
    }

    private fun stopPolling() {
        pollRunnable?.let { handler.removeCallbacks(it) }
        pollRunnable = null
    }

    override fun onDestroy() {
        stopPolling()
        players.forEach { it.release() }
        super.onDestroy()
    }
}
